# Antrasit Theme Website

Template website sederhana bertema antrasit (dark grey).

## Fitur
- Desain modern & minimalis
- Responsive
- Siap upload ke GitHub

## Cara Menjalankan
Cukup buka file `index.html` di browser.

---
Dibuat untuk kebutuhan commit GitHub 🚀
